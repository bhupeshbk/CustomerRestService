<?php
include_once("class_sms_mail_notify.php");
/* —————————————————————————————————————————————————————————————————————————————————————
* New Code for Firebase FCM Push Notification Android
* ————————————————————————————————————————————————————————————————————————————————————— */
/*class SendNotification 
{ 	
	private static $API_SERVER_KEY = 'AIzaSyAAyE2FDJGa2DTPA7I0RRCLt2_xbbPn9dw';
	public function __construct() {		
	
	}
	public function sendPushNotificationToFCMSever($token, $message ,$postID) {
		$path_to_firebase_cm = 'https://fcm.googleapis.com/fcm/send';		
		$fields = array(
			'to' => $token,
			'priority' => 10,
			'notification' => array('title' => 'Demo Notify', 'body' => $message ),
			'data'         => array('title' => 'Demo Notify', 'message' => $message )
		);	
		$headers = array(
			'Authorization:key=' . self::$API_SERVER_KEY,
			'Content-Type:application/json'
		);		
		$ch = curl_init(); 
		curl_setopt($ch, CURLOPT_URL, $path_to_firebase_cm); 
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 ); 
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));    
		$result = curl_exec($ch);       
		curl_close($ch);
		return $result;
	}
}*/


/* —————————————————————————————————————————————————————————————————————————————————————
* Call notify class
* ————————————————————————————————————————————————————————————————————————————————————— */
$serverObject = new SendNotification();	

$token 	 = "cqnJsrzXxxs:APA91bHOrbfOJVTMdrvqCBHU502cgyKt9r30t0f2LqJhciZtivnOIDdSSKn4_R8xKx2obZQa5nBxJFVJse9Wu6zfVPFce9cXuhq4uCRIM3szq_Ki-bKAUziRJ4nM_wwb4vDx180iI2d9";
$message = "Enter Your Message";
$img = "http://localhost:81/app.motosurgeon.com/assets/images/logo/1487401846.png";

$jsonString = $serverObject->sendPushNotificationToGCMSever( $token, $message, $img );	

//print_r( $jsonString );

$jsonObject = json_decode( $jsonString );

print_r( $jsonObject );

/*if( $jsonObject->failure != 0 )
{			
	echo "failed";			
}
else
{
	echo "success";		
}*/
?>