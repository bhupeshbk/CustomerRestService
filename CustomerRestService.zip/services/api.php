<?php
ob_start();
date_default_timezone_set("Asia/Calcutta");
$created=date('Y-m-d h:i:s a'); //Returns IST 
require_once("../Rest.inc.php");
include_once("../class_sms_mail_notify.php");

class API extends REST {
	public $data="";

	const DB_SERVER = 'localhost';	
	const DB_USER = 'root';
	const DB_PASSWORD = '';
	const DB = 'streat_foods';

	const IP_URL       = "http://192.168.0.102:81/streat_foods/";
	const IMGcustomer    = "assets/images/customers/";		

	private $db 	= NULL;
	private $mysqli = NULL;
	public function __construct() {	
		parent::__construct();
		$this->dbConnect();
	}
	/* —————————————————————————————————————————————————————————————————————————————————————
	* Coonect to DB
	* ————————————————————————————————————————————————————————————————————————————————————— */
	public function dbConnect() {
		$this->mysqli = new mysqli(self::DB_SERVER,self::DB_USER,self::DB_PASSWORD,self::DB);
		$this->mysqli->set_charset("utf8");
	}
	/* —————————————————————————————————————————————————————————————————————————————————————
	* Dynmically call the method based on the query string
	* ————————————————————————————————————————————————————————————————————————————————————— */
	public function processApi() {
		$func = strtolower(trim(str_replace("/","",$_REQUEST['x'])));
		if((int)method_exists($this,$func)>0) {
			$this->$func();
		}
		else{
			$this->response('','404');
		}
	}
	###### End grab the all posts cat and tag and comments list and insert from the db

	/* —————————————————————————————————————————————————————————————————————————————————————
	* All Action for Login
	* ————————————————————————————————————————————————————————————————————————————————————— */
	//Insert Login_Fb_GG
	private function Login_Fb_GG(){
		if($this->get_request_method() != "POST"){
			$this->response('',406);
		}
		$response['LoginDetails'] = array();				
		$emailmobile 	= mysqli_real_escape_string($this->mysqli, $_REQUEST['emailmobile']);
		$password 		= mysqli_real_escape_string($this->mysqli,$_REQUEST['password']);		
		$oauth_provider = mysqli_real_escape_string($this->mysqli, $_REQUEST['oauth_provider']);	
		$oauth_uid 		= mysqli_real_escape_string($this->mysqli, $_REQUEST['oauth_uid']);		
		$name 			= mysqli_real_escape_string($this->mysqli, $_REQUEST['name']);			
		$regid 			= mysqli_real_escape_string($this->mysqli, $_REQUEST['regid']);
		$udid 			= mysqli_real_escape_string($this->mysqli, $_REQUEST['udid']);
		$os 			= mysqli_real_escape_string($this->mysqli, $_REQUEST['os']);		
		$profile_url 	= mysqli_real_escape_string($this->mysqli, $_REQUEST['profile_url']);

		if(empty($oauth_provider) || empty($emailmobile)) {
			$this->response('',204);
			die;
		}
		if(!empty($oauth_provider)) {
			if($oauth_provider == "inapp" || $oauth_provider == "web") {
				$query_login = "SELECT * FROM customer  WHERE (mobile='$emailmobile' or email='$emailmobile') 
								and password='$password' 
								and is_delete='no' 
								and is_active='yes'  
								LIMIT 1";
			}
			else {
				$query_login = "SELECT * FROM customer WHERE (mobile='$emailmobile' or email='$emailmobile') 
								and oauth_uid='$oauth_uid'
								and is_delete='no' 
								and is_active='yes'  LIMIT 1";
			}
			//echo $query_login;
			$rs_login = $this->mysqli->query($query_login) or die($this->mysqli->error.__LINE__);
			if($rs_login->num_rows > 0) {
				$row_login = $rs_login->fetch_assoc();
				$is_active = $row_login['is_active'];
				if( $is_active == "yes" ) {
					############### Check email and mobile ##################
					$qr_verify_main = "SELECT * from customer where (mobile='$emailmobile' or email='$emailmobile') LIMIT 1";
					$row_vf_main    = $this->mysqli->query($qr_verify_main) or die($this->mysqli->error.__LINE__);
					if($row_vf_main->num_rows > 0) {
						$row_em_m = $row_vf_main->fetch_assoc();
						if( $row_em_m['mobile_verify'] == 'no') {
							//$arr=$row_em_m;
							$arr['id'] 		= $row_em_m['id'];
							$arr['email']   = $row_em_m['email'];
							$arr['name'] 	= $row_em_m['name'];
							$arr['mobile'] 	= $row_em_m['mobile'];

							$arr["msg"]		= "mobile not verify.";	
							$arr["id"]		= $row_em_m['id'];
							$arr["status"]	= "failed";	
							array_push($response["LoginDetails"],$arr);	
							$this->response($this->json($response), 200);
							die;
						}
						elseif( $row_em_m['email_verify'] == 'no' && empty($row_em_m['oauth_uid'])) {
							//$arr=$row_em_m;
							$arr['id'] 		= $row_em_m['id'];
							$arr['email']   = $row_em_m['email'];
							$arr['name'] 	= $row_em_m['name'];
							$arr['mobile'] 	= $row_em_m['mobile'];

							$arr["msg"]		= "email not verify.";	
							$arr["id"]		= $row_em_m['id'];
							$arr["status"]	= "failed";	
							array_push($response["LoginDetails"],$arr);	
							$this->response($this->json($response), 200);
							die;
						}
						else {		
							if($oauth_provider == "inapp" || $oauth_provider == "web") {	
								$res_up = $this->mysqli->query("UPDATE customer set os='$os',regid='$regid',udid='$udid' where id='".$row_login['id']."'");	
							}
							else {
								$res_up = $this->mysqli->query("UPDATE customer set os='$os',regid='$regid',udid='$udid',profile_url='$profile_url' where id='".$row_login['id']."'");	
							}

							$res_selnew = $this->mysqli->query("
								SELECT id, email, name, mobile, regid, udid, os, created, oauth_provider, oauth_uid, mobile_verify, email_verify, profile_url, gender, country, state, city, 
									IFNULL( (select cn.name from country as cn where cn.id=customer.country),'' ) as countryname,
									IFNULL( (select st.name from state as st where st.id=customer.state),'' ) as statename, 
									IFNULL( (select ct.name from city as ct where ct.id=customer.city),'' ) as cityname 
								from  
									customer 
								where 
									id='".$row_login['id']."'");
							$row_selnew_login = $res_selnew->fetch_assoc();	

							$arr = $row_selnew_login;	
							$arr["image_path"] = self::IP_URL.self::IMGcustomer;

							$arr["status"] = "success";
							$arr["msg"] = "Your account is activated";	
							array_push($response["LoginDetails"],$arr);
							$this->response($this->json($response), 200);
						}
					}
					else {
						$arr["status"] = "failed";
						$arr["msg"] = "Invalid email or password.";	
						array_push($response["LoginDetails"],$arr);	
						$this->response($this->json($response), 200);
					}
					############### End Check email and mobile ###################
				}
				else {
					$arr["status"] = "failed";
					$arr["msg"] = "Your account is deactivated.";
					array_push($response["LoginDetails"],$arr);	
					$this->response($this->json($response), 200);
				}
			}
			else {
				$arr["status"] = "failed";
				$arr["msg"] = "Invalid email or password.";	
				array_push($response["LoginDetails"],$arr);	
				$this->response($this->json($response), 200);
			}
		}
	}
	//forgot Password
	private function ForgotPassword(){
		if($this->get_request_method() != "POST"){
			$this->response('',406);
		}
		$response['ForgotPassword'] = array();	
		$email = mysqli_real_escape_string($this->mysqli, $_REQUEST['email']);	
		if( !empty($email) ) {
			$query = "SELECT id FROM customer WHERE email='$email' and mobile_verify='yes' and email_verify='yes' and is_delete='no' and is_active='yes' LIMIT 1";
			$r = $this->mysqli->query($query) or die($this->mysqli->error.__LINE__);
			if($r->num_rows > 0) {
				$email_arr = explode("@",$email);
				$name   = $email_arr[0];		
				$otp    = rand(111111,999999);
				$ekey   = md5($email).$otp;		

				$query_otp = "INSERT INTO app_otp_ekey(id,emai_and_mobile,otp_no)VALUES (null,'".$email."','".$ekey."') ON DUPLICATE KEY UPDATE otp_no='".$ekey."'";
				if($this->mysqli->query($query_otp))  {
					$Subject = "Forgot Password";
					$to = $email;
					$to_name = $name;
					$verify_linkl = self::IP_URL."CustomerRestService/password-change.php?stt=reg&ekey=".$ekey."&id=id";
					$html1 = file_get_contents('../mailtemp_forgot.txt');
					$html2 = str_replace('{{email_id}}', $to, $html1);
					$html = str_replace('{{verify_linkl}}', $verify_linkl, $html2);
					#################### Send mail ####################
					$serverObject_fun =  $this->Mail_func( $Subject, $to, $to_name, $html );
					if($serverObject_fun == "failed") {
						$arr["status"] = "failed";
						$arr['msg']    = "Error in mail send.";			
					}
					else {
						$arr["status"] = "success";
						$arr['msg']    = "Check your mail to change your password.";
					}					
				}		
				array_push($response["ForgotPassword"],$arr);	
				$this->response($this->json($response), 200);				
			}
			else {
				$arr["status"] = "failed";
				$arr["msg"] = "Invalid User/email";	
				array_push($response["ForgotPassword"],$arr);	
				$this->response($this->json($response), 200);
			}
		}
		else {
			$this->response('',204);
		}
	}
	//Change Password
	private function ChangePassword(){
		if($this->get_request_method() != "POST"){
			$this->response('',406);
		}
		$response['ChangePassword'] = array();
		$uid 			  = mysqli_real_escape_string($this->mysqli, $_REQUEST['uid']);
		$current_password = mysqli_real_escape_string($this->mysqli, $_REQUEST['current_password']);	
		$password 		  = mysqli_real_escape_string($this->mysqli, $_REQUEST['password']);	

		if(!empty($uid) || !empty($current_password) || !empty($password)) {
			$query = "SELECT id FROM customer WHERE password='$current_password' and id='$uid' and is_delete='no' and is_active='yes' LIMIT 1";
			$r = $this->mysqli->query($query) or die($this->mysqli->error.__LINE__);
			if($r->num_rows > 0) {
				$query = "UPDATE customer set password='$password' where id='$uid'";	
				$r =  $this->mysqli->query($query) or die($this->mysqli->error.__LINE__);
				if( mysqli_affected_rows( $this->mysqli ) > 0 ) {
					$arr["status"] = "success";
					$arr["msg"] = "Password updated.";						
				}
				else {
					$arr["status"] = "failed";
					$arr["msg"] = "You should use different password";
				}				
			}
			else {
				$arr["status"] = "failed";
				$arr["msg"] = "Invalid User/Password";	
			}
			array_push($response["ChangePassword"],$arr);	
			$this->response($this->json($response), 200);
		}
		else {
			$this->response('',204);
		}
	}
	//Change Mobile No
	private function ChangeMobileNo(){
		if($this->get_request_method() != "POST"){
			$this->response('',406);
		}
		$response['Changemobile'] = array();
		$uid 	= mysqli_real_escape_string($this->mysqli, $_REQUEST['uid']);
		$mobile = mysqli_real_escape_string($this->mysqli, $_REQUEST['mobile']);		
		if( !empty($uid) && !empty($mobile) ) {
			$query = "SELECT id FROM customer WHERE mobile='$mobile' LIMIT 1";
			//echo $query;
			$r = $this->mysqli->query($query) or die($this->mysqli->error.__LINE__);
			if($r->num_rows > 0)  {
				$arr["status"] = "failed";
				$arr["msg"] = "Mobile no not available";					
			}
			else {
				$query_mobup = "UPDATE customer set mobile='$mobile' where id='$uid'";	
				//echo $query_mobup;
				$rs_mobup = $this->mysqli->query($query_mobup) or die($this->mysqli->error.__LINE__);

				$arr["status"] = "success";
				$arr["msg"] = "Mobile no updated.";	
			}
			array_push($response["Changemobile"],$arr);	
			$this->response($this->json($response), 200);
		}
		else {
			$this->response('',204);
		}
	}
	//Change Email ID
	private function ChangeEmail(){
		if($this->get_request_method() != "POST"){
			$this->response('',406);
		}
		$response['Changeemail'] = array();
		$uid   = mysqli_real_escape_string($this->mysqli, $_REQUEST['uid']);
		$email = mysqli_real_escape_string($this->mysqli, $_REQUEST['email']);		
		if(!empty($uid) && !empty($email) ) {
			$query = "SELECT id FROM customer WHERE email='$email' LIMIT 1";
			//echo $query;
			$r = $this->mysqli->query($query) or die($this->mysqli->error.__LINE__);
			if($r->num_rows > 0) {
				$arr["status"] = "failed";
				$arr["msg"] = "Email id not available";					
			}
			else {
				$query_emailup = "UPDATE customer set email='$email' where id='$uid'";	
				//echo $query_mobup;
				$rs_emialup = $this->mysqli->query($query_emailup) or die($this->mysqli->error.__LINE__);

				$arr["status"] = "success";
				$arr["msg"] = "Email id updated.";	
			}
			array_push($response["Changeemail"],$arr);	
			$this->response($this->json($response), 200);
		}
		else {
			$this->response('',204);
		}
	}
	//Log out
	private function Logout() {	
		if($this->get_request_method() != "POST"){
			$this->response('',406);
		}
		$response['Logout'] = array();

		$userid = $_REQUEST['userid'];
		$os 	= $_REQUEST['os'];	
		if(!empty($userid)) {
			if($os == "android") {
				$query_u = "UPDATE customer set regid='' where id='$userid'";
				//echo $query_u;
				$r_u = $this->mysqli->query($query_u) or die($this->mysqli->error.__LINE__);
			}
			if($os == "ios") {
				$query_u = "UPDATE customer set udid='' where id='$userid'";
				$r_u = $this->mysqli->query($query_u) or die($this->mysqli->error.__LINE__);
			}			
			$arr['status'] = "success";
			$arr['msg'] = "Logged out";
			array_push($response["Logout"],$arr);			
			$this->response($this->json($response), 200); 
		}
		$this->response('',204);
	}
	//Check_Login_user
	private function Check_Login_user(){	
		if($this->get_request_method() != "POST") {
			$this->response('',406);
		}
		$response['Login_user'] = array();			
		$userid = $_REQUEST['userid'];	
		if(!empty($userid)) {
			$query_u = "SELECT * from customer where id='$userid'";
			$r_u = $this->mysqli->query($query_u) or die($this->mysqli->error.__LINE__);
			if($r_u->num_rows > 0) {
				$row = $r_u->fetch_assoc();
				if( $row['is_active'] != "yes") {
					$arr['status'] = "failed";
					$arr['msg'] = "User not active";
				}
				elseif( $row['is_delete'] != "no") {
					$arr['status'] = "failed";
					$arr['msg'] = "User deleted";
				}
				else {					
					$arr['status'] = "success";
					$arr['msg'] = "Logged in";
				}
			}
			else {
				$arr['status'] = "failed";
				$arr['msg'] = "Account Deleted";
			}				
			array_push($response["Login_user"],$arr);			
			$this->response($this->json($response), 200); 
		}
		$this->response('',204);
	}
	//	MobileNo email check
	private function Mobileno_email_chk() {
		if($this->get_request_method() != "POST") {
			$this->response('',406);
		}
		$mobile = mysqli_real_escape_string($this->mysqli, $_REQUEST['mobile']);
		$email  = mysqli_real_escape_string($this->mysqli, $_REQUEST['email']);
		if(!empty($mobile) || !empty($email)) {
			$fieldName   = ( (!empty($mobile)) ? "mobile"  : ( (!empty($email)) ? "email" : "" ) );
			$fieldValues = ( (!empty($mobile)) ? $mobile   : ( (!empty($email)) ? $email  : "" ) );

			$query="SELECT *  FROM customer WHERE ".$fieldName."= '".$fieldValues."'";
			//echo $query;
			$r = $this->mysqli->query($query) or die($this->mysqli->error.__LINE__);
			if($r->num_rows > 0) {					
				$response1["status"] = array();
				$success['status'] = "failed";
				$success['msg'] = "".$fieldName." not available.";	
				array_push($response1["status"],$success);
				$this->response($this->json($response1), 200);
			}
			else {					
				$response1["status"] = array();
				$success['status'] = "success";
				$success['msg'] = "".$fieldName." available.";	
				array_push($response1["status"],$success);
				$this->response($this->json($response1), 200);	
			}
		}
		else {				
			$response1["status"] = array();
			$success['status'] = "failed";
			$success['msg'] = "Invalid MobileNo/email.";	
			array_push($response1["status"],$success);
			$this->response($this->json($response1), 200);
		}
	}
	//Send Mail
	private function mailSend() {
		if($this->get_request_method() != "POST") {
			$this->response('',406);
		}
		$response["status"] = array();
		### $name   = mysqli_real_escape_string( $this->mysqli, $_REQUEST['name'] );
		$email  = mysqli_real_escape_string( $this->mysqli, $_REQUEST['email'] );		
		$otp    = rand(111111,999999);
		$ekey   = md5($email).$otp;		

		if( empty($email) && empty($ekey) ) {
			$this->response( '', 204 );
		}				
		$query_otp = "INSERT INTO app_otp_ekey(id,emai_and_mobile,otp_no)VALUES (null,'$email','$ekey') 
					ON DUPLICATE KEY UPDATE otp_no='".$ekey."'";
		if( $this->mysqli->query( $query_otp ) ) {
			$Subject = "Email Verification";
			$to = $email;
			$to_name = $email;
			$verify_linkl = self::IP_URL."CustomerRestService/verifymail-check.php?sf=_tf&ekey=".$ekey;
			$html1 = file_get_contents('../mail_template.txt');
			$html2 = str_replace('{{email_id}}', $to, $html1);
			$html = str_replace('{{verify_linkl}}', $verify_linkl, $html2);
			#################### Send mail ####################
			$serverObject_fun =  $this->Mail_func( $Subject, $to, $to_name, $html );
			if($serverObject_fun == "failed") {
				$arr["status"] = "failed";
				$arr['msg']    = "Error in mail send.";			
			}
			else {
				$arr["status"] = "success";
				$arr['msg']    = "Mail send.";
			}			
		}
		else {
			$arr["status"] = "failed";
			$arr['msg']    = "Error in mail send.Please try again later.";
		}
		array_push( $response["status"], $arr );	
		$this->response( $this->json( $response ), 200 );					
	}
	// mail verify
	private function mailSend_Verify() {
		if( $this->get_request_method() != "POST" ){
			$this->response('',406);
		}
		$response["status"] = array();
		//$email = mysqli_real_escape_string( $this->mysqli, $_REQUEST['email'] );
		$id = mysqli_real_escape_string( $this->mysqli, $_REQUEST['id'] );		
		if( empty( $id ) ) {
			$this->response( '', 204 );
		}
		$qr = "SELECT * from customer where id='$id' and email_verify='yes'";
		$r  = $this->mysqli->query( $qr ) or die($this->mysqli->error.__LINE__);
		if( $r->num_rows > 0 ) {
			$arr["status"] = "success";
			$arr['msg']    = "Email verify.";			
		}
		else {
			$arr["status"] = "failed";
			$arr['msg']    = "Please check and verify your email.";
		}	
		array_push( $response["status"], $arr );	
		$this->response( $this->json( $response ), 200 );						
	}
	//Send Otp Sms
	private function otpSend() {
		if($this->get_request_method() != "POST") {
			$this->response('',406);
		}
		$response["status"] = array();
		### $name   = mysqli_real_escape_string( $this->mysqli, $_REQUEST['name'] );
		$mobile = mysqli_real_escape_string( $this->mysqli, $_REQUEST['mobile'] );		
		$otp    = "1234";//rand(1111,9999);	

		if( empty($mobile) && empty($otp) ) {
			$this->response( '', 204 );
		}				
		$query_otp = "INSERT INTO app_otp_ekey(id,emai_and_mobile,otp_no)VALUES (null,'$mobile','$otp') 
					ON DUPLICATE KEY UPDATE otp_no='".$otp."'";
		if( $this->mysqli->query( $query_otp ) ) {
			$message_send = "Your OTP for street foods App is : ".$otp." \n\rTeam Street Foods." ;
			################ Send Otp mobile ################
			/*$serverObject_fun =  $this->SMS_func($mobile ,$message_send );
			if($serverObject_fun == "failed") {
				$arr["status"] = "fail";
				$arr['msg']    = "Error in sms send.";			
			}
			else {
				$arr["status"] = "success";
				$arr['msg']    = "Sms send.";
			}*/	
			$arr["status"] = "success";
			$arr['msg']    = "Sms send.";		
		}
		else {
			$arr["status"] = "failed";
			$arr['msg']    = "Error in sms send.Please try again later.";
		}
		array_push( $response["status"], $arr );	
		$this->response( $this->json( $response ), 200 );					
	}
	// OTP Verify
	private function otpSend_verify() {
		if($this->get_request_method() != "POST"){
			$this->response('',406);
		}
		$response["status"] = array();
		$mobile = mysqli_real_escape_string( $this->mysqli, $_REQUEST['mobile'] );
		$otp    = mysqli_real_escape_string( $this->mysqli, $_REQUEST['otp'] );
		$id     = mysqli_real_escape_string( $this->mysqli, $_REQUEST['id'] );
		###### 
		$qr = "SELECT id from app_otp_ekey where emai_and_mobile='$mobile' and otp_no='$otp'";
		$r  = $this->mysqli->query( $qr ) or die( $this->mysqli->error.__LINE__ );
		if($r->num_rows > 0) {
			while($row=$r->fetch_assoc()) {
				$query_u = "UPDATE customer set mobile='$mobile',mobile_verify='yes' where id='$id'";
				$r_u = $this->mysqli->query( $query_u ) or die( $this->mysqli->error.__LINE__ );
				### echo $query_u;
				###### 
				$query_otp="delete from app_otp_ekey where id='".$row['id']."'";
				if( $this->mysqli->query($query_otp) ) {
					$arr["status"] = "success";
					$arr['msg']    = "Otp verify.";	
				}
				else {		
					$arr["status"] = "failed";
					$arr['msg']    = "Otp not verify.";
				}
			}			
		}
		else {
			$arr["status"] = "failed";
			$arr['msg']    = "Invalid OTP.";	
		}	
		array_push( $response["status"], $arr );	
		$this->response( $this->json( $response ), 200 );				
	}
	###### End All Action for Login
	/* —————————————————————————————————————————————————————————————————————————————————————
	* All Action for Customer
	* ————————————————————————————————————————————————————————————————————————————————————— */
	//Select Customer by id
	private function CustomerProfile() {	
		if($this->get_request_method() != "POST"){
			$this->response('',406);
		}
		$id = mysqli_real_escape_string( $this->mysqli, $_REQUEST['id'] );
		$response['Customer'] = array();		
		$query = "SELECT * from customer where id='$id' and is_delete='no' and is_active='yes' and mobile_verify='yes'";
		$r = $this->mysqli->query($query) or die($this->mysqli->error.__LINE__);
		if($r->num_rows > 0) {
			while($row=$r->fetch_assoc()) {
				$arr = $row;
			}		
			array_push($response["Customer"],$arr);			
			$this->response($this->json($response), 200);
		}
		else {
			$this->response('',204);
		}
	}
	//Insert Customer
	private function InsertCustomer() {
		if($this->get_request_method() != "POST"){
			$this->response('',406);
		}

		$oauth_provider = mysqli_real_escape_string($this->mysqli, $_REQUEST['oauth_provider']);
		$oauth_uid 		= mysqli_real_escape_string($this->mysqli, $_REQUEST['oauth_uid']);
		$name     		= mysqli_real_escape_string($this->mysqli, $_REQUEST['name']);	
		$mobile   		= mysqli_real_escape_string($this->mysqli, $_REQUEST['mobile']);
		$email    		= mysqli_real_escape_string($this->mysqli, $_REQUEST['email']);					
		$password 		= mysqli_real_escape_string($this->mysqli, $_REQUEST['password']);
		$gender 		= mysqli_real_escape_string($this->mysqli, $_REQUEST['gender']);
		$country 		= mysqli_real_escape_string($this->mysqli, $_REQUEST['country']);
		$state 			= mysqli_real_escape_string($this->mysqli, $_REQUEST['state']);
		$city			= mysqli_real_escape_string($this->mysqli, $_REQUEST['city']);
		//$profile_url	= mysqli_real_escape_string($this->mysqli, $_REQUEST['profile_url']);
		$regid 			= mysqli_real_escape_string($this->mysqli, $_REQUEST['regid']);
		$udid 			= mysqli_real_escape_string($this->mysqli, $_REQUEST['udid']);
		$os 			= mysqli_real_escape_string($this->mysqli, $_REQUEST['os']);
		$created	=	date('Y-m-d H:i:s');
		############### Check email and mobile ###################
		$query = "SELECT * FROM customer WHERE (email='$email' or mobile='$mobile')";
		//echo $query;
		$r = $this->mysqli->query($query) or die($this->mysqli->error.__LINE__);
		if($r->num_rows > 0) {
			$response1["status"]= array();
			$row=$r->fetch_assoc();
			if($row['mobile']==$mobile && $row['email']==$email) {
				$success['status'] = "failed";
				$success['msg'] = "User already registered";	
				array_push($response1["status"],$success);
				$this->response($this->json($response1), 200);
				die;
			}
			elseif( $row['mobile']==$mobile) {
				$success['status'] = "failed";
				$success['msg'] = "Mobile No already exists";	
				array_push($response1["status"],$success);
				$this->response($this->json($response1), 200);
				die;
			}
			elseif($row['email']==$email) {
				$success['status'] = "failed";
				$success['msg'] = "Email Id already exists";	
				array_push($response1["status"],$success);
				$this->response($this->json($response1), 200);
				die;			
			}
		}
		############### End Check email and mobile ###################
		if($oauth_provider == "facebook" || $oauth_provider == "google") {
			$email_verify = "yes";
		}
		else {
			$email_verify = "no";
		}
		########################################################################################
		//print_r($_FILES['profile_url']['name']);
		if ( empty( $_FILES['profile_url']['name'] ) ) { 
		    $profile_url	= mysqli_real_escape_string($this->mysqli, $_REQUEST['profile_url']);
		}
		else {
		    $fileinfo = pathinfo($_FILES['profile_url']['name']);
			$extension = $fileinfo['extension'];
			#$file_url = $upload_url . getFileName() . '.' . $extension;
			$file_name = time() . '.' . $extension;
			$file_path_upload = $_SERVER['DOCUMENT_ROOT']. '/streat_foods/' . self::IMGcustomer . $file_name;
			//trying to save the file in the directory 
			try { 
				move_uploaded_file($_FILES['profile_url']['tmp_name'],$file_path_upload); 

				$profile_url = "".$file_name;
			}
			catch(Exception $e) {
				$success['error']=true;
				$success['image_message']=$e->getMessage();
			}		
		}
		########################################################################################
		$query1 = "INSERT INTO customer(oauth_provider, oauth_uid, name, mobile, email, password, gender, country, state, city, profile_url, email_verify, mobile_verify, is_active, is_delete, created, modified, regid, udid, os) 
						VALUES ('$oauth_provider', '$oauth_uid', '$name', '$mobile', '$email', '$password', '$gender', '$country', 
						'$state', '$city', '$profile_url', '$email_verify', 'no', 'yes', 'no', '$created', '$created', '$regid', '$udid', '$os')";
		//echo $query;		
		$r1 = $this->mysqli->query($query1 ) or die($this->mysqli->error.__LINE__);
		$last_id = mysqli_insert_id($this->mysqli);
		if($r1>0) {
			$id= $last_id;						
			$response1["status"]= array();
			$success['status'] = "success";
			$success['id'] = $id;
			$success['msg'] = "User Created Successfully.";	
			array_push($response1["status"],$success);
			$this->response($this->json($response1), 200);
		}
		else {
			$this->response('',204);
		}
		############### End Insert ##################
	}
	private function UpdateCustomer() {
		if($this->get_request_method() != "POST"){
			$this->response('',406);
		}
		$response["UpdateCustomer"] = array();
		$id = mysqli_real_escape_string($this->mysqli, $_REQUEST['id']);

		$oauth_provider = mysqli_real_escape_string($this->mysqli, $_REQUEST['oauth_provider']);
		$oauth_uid 		= mysqli_real_escape_string($this->mysqli, $_REQUEST['oauth_uid']);
		$name     		= mysqli_real_escape_string($this->mysqli, $_REQUEST['name']);	
		$mobile   		= mysqli_real_escape_string($this->mysqli, $_REQUEST['mobile']);
		$email    		= mysqli_real_escape_string($this->mysqli, $_REQUEST['email']);					
		//$password 	= mysqli_real_escape_string($this->mysqli, $_REQUEST['password']);
		$gender 		= mysqli_real_escape_string($this->mysqli, $_REQUEST['gender']);
		$country 		= mysqli_real_escape_string($this->mysqli, $_REQUEST['country']);
		$state 			= mysqli_real_escape_string($this->mysqli, $_REQUEST['state']);
		$city			= mysqli_real_escape_string($this->mysqli, $_REQUEST['city']);
		//$profile_url	= mysqli_real_escape_string($this->mysqli, $_REQUEST['profile_url']);
		$regid 			= mysqli_real_escape_string($this->mysqli, $_REQUEST['regid']);
		$udid 			= mysqli_real_escape_string($this->mysqli, $_REQUEST['udid']);
		$os 			= mysqli_real_escape_string($this->mysqli, $_REQUEST['os']);

		$new_mobile  =  mysqli_real_escape_string($this->mysqli, $_REQUEST['new_mobile']);
		$new_email   =  mysqli_real_escape_string($this->mysqli, $_REQUEST['new_email']);



		$file = 'error_log';
		$current = file_get_contents($file);
		$current .= "id-".$id . "\n";
		$current .= "oauth_uid-".$oauth_uid . "\n";
		$current .= "name-".$name . "\n";
		$current .= "mobile-".$mobile . "\n";
		$current .= "email-".$email . "\n";
		$current .= "gender-".$gender . "\n";
		$current .= "country-".$country . "\n";
		$current .= "state-".$state . "\n";
		$current .= "city-".$city . "\n";
		$current .= "regid-".$regid . "\n";
		$current .= "udid-".$udid . "\n";
		$current .= "os-".$os . "\n";
		$current .= "new_mobile-".$new_mobile . "\n";
		$current .= "new_email-".$new_email . "\n";
		$current .= "profile_url-".$_FILES['profile_url']['name'] . "\n";
		file_put_contents($file, $current);

		$created	=	date('Y-m-d H:i:s');

		$mobile_verify  =  ""; $email_verify   =  ""; $mobile_chk  =  ""; $email_chk   =  "";
		if(!empty($id)) {
			if( !empty($new_mobile) && !empty($new_email) ) {
				##Check Mobile
				$qr_avail_mob  =  "SELECT * from customer where mobile='$new_mobile' LIMIT 1";
				$rs_avail_mob  =  $this->mysqli->query($qr_avail_mob) or die($this->mysqli->error.__LINE__);
				if($rs_avail_mob->num_rows > 0) {
					$arr["msg"]  =  "Mobile no not available";	
					$arr["id"]  =  $id;
					$arr["status"]  =  "failed";	
					array_push($response["UpdateCustomer"],$arr);	
					$this->response($this->json($response), 200);
					die;
				}
				else {
					$mobile_verify  =  "no";
					$mobile_chk =  $new_mobile;
				}
				##Check Email
				$qr_avail_email = "SELECT * from customer where email='$new_email' LIMIT 1";
				$rs_avail_email = $this->mysqli->query($qr_avail_email) or die($this->mysqli->error.__LINE__);
				if($rs_avail_email->num_rows > 0) {
					$arr["msg"] = "Email id not available";	
					$arr["id"] = $id;
					$arr["status"] = "failed";	
					array_push($response["UpdateCustomer"],$arr);	
					$this->response($this->json($response), 200);
					die;						
				}
				else {
					$email_verify  =  "no";
					$email_chk =  $new_email;
				}
			}
			elseif( !empty($new_mobile) && empty($new_email) ) {
				##Check Mobile
				$qr_avail_mob  =  "SELECT * from customer where mobile='$new_mobile' LIMIT 1";
				$rs_avail_mob  =  $this->mysqli->query($qr_avail_mob) or die($this->mysqli->error.__LINE__);
				if($rs_avail_mob->num_rows > 0)  {
					$arr["msg"]  =  "Mobile no not available";	
					$arr["id"]   =  $id;
					$arr["status"]  =  "failed";	
					array_push($response["UpdateCustomer"],$arr);	
					$this->response($this->json($response), 200);
					die;
				}
				else {
					$mobile_verify  =  "no";
					$mobile =  $new_mobile;
				}
				## Email Not Check
				$email_verify  =  "yes";
				$email_chk =  $email;
			}
			elseif( empty($new_mobile) && !empty($new_email) ) {
				##Check Email
				$qr_avail_email = "SELECT * from customer where email='$new_email' LIMIT 1";
				$rs_avail_email = $this->mysqli->query($qr_avail_email) or die($this->mysqli->error.__LINE__);
				if($rs_avail_email->num_rows > 0) 
				{
					$arr["msg"] = "Email id not available";	
					$arr["id"] = $id;
					$arr["status"] = "failed";	
					array_push($response["UpdateCustomer"],$arr);	
					$this->response($this->json($response), 200);
					die;						
				}
				else {
					$email_verify  =  "no";
					$email =  $new_email;
				}
				## Mobile Not Check
				$mobile_verify  =  "yes";
				$mobile_chk =  $mobile;
			}
			elseif( empty($new_mobile) && empty($new_email) ) {
				## Email Not Check
				$email_verify  =  "yes";
				$email_chk =  $email;

				## Mobile Not Check
				$mobile_verify  =  "yes";
				$mobile_chk =  $mobile;
			}

			$query="SELECT *  FROM customer WHERE id= '".$id."' and is_delete='no'";
			$r = $this->mysqli->query($query) or die($this->mysqli->error.__LINE__);
			if($r->num_rows > 0)  {	
				########################################################################################
				//print_r($_FILES['profile_url']['name']);
				if ( empty( $_FILES['profile_url']['name'] ) ) { 
				    $profile_url	= mysqli_real_escape_string($this->mysqli, $_REQUEST['profile_url']);
				}
				else {
				    $fileinfo = pathinfo($_FILES['profile_url']['name']);
					$extension = $fileinfo['extension'];
					#$file_url = $upload_url . getFileName() . '.' . $extension;
					$file_name = time() . '.' . $extension;
					$file_path_upload = $_SERVER['DOCUMENT_ROOT']. '/streat_foods/' . self::IMGcustomer . $file_name;
					//trying to save the file in the directory 
					try { 
						move_uploaded_file($_FILES['profile_url']['tmp_name'],$file_path_upload); 

						$profile_url = "".$file_name;
					}
					catch(Exception $e) {
						$success['error']=true;
						$success['image_message']=$e->getMessage();
					}		
				}
				########################################################################################				
				$query = "UPDATE customer set email='$email_chk', name='$name', mobile='$mobile_chk', regid='$regid', udid='$udid', os='$os', 
							modified='$created',gender='$gender', profile_url='$profile_url', mobile_verify='$mobile_verify', 
							email_verify='$email_verify',country='$country', state='$state', city='$city'  
					where  id='$id'";									
				$r = $this->mysqli->query($query) or die($this->mysqli->error.__LINE__);

				if($mobile_verify == "no") {
					$success['new_mobileverify_msg'] = "Mobile not verify";
				}
				if($email_verify  ==  "no") {
					$success['new_emailverify_msg'] = "Email not verify";
				}
				$success['status'] = "success";
				$success['msg'] = "Data updated Successfully.";	
				array_push($response["UpdateCustomer"],$success);
				$this->response($this->json($response), 200);
			}
			else {
				$success['status'] = "failed";
				$success['msg'] = "User not exists!";	
				array_push($response["UpdateCustomer"],$success);
				$this->response($this->json($response), 200);
			}			
		}
		else {			
			$success['status'] = "failed";
			$success['msg'] = "User not exists!";	
			array_push($response["UpdateCustomer"],$success);
			$this->response($this->json($response), 200);
		}
	}
	//Delete Customer
	private function DeleteCustomer(){	
		if($this->get_request_method() != "POST"){
			$this->response('',406);
		}
		$id = mysqli_real_escape_string($this->mysqli, $_REQUEST['id'] );	
		if(!empty($id)) {
			$query_wp = "SELECT email from customer where id='".$id."' ";
			$rwp = $this->mysqli->query($query_wp) or die($this->mysqli->error.__LINE__);
			if($rwp->num_rows > 0)  {
				$query = "UPDATE customer SET is_delete='yes' where id='".$id."' ";
				$r = $this->mysqli->query($query) or die($this->mysqli->error.__LINE__);

				$response1["status"]= array();
				$success['status'] = "success";
				$success['msg'] = "customer Deleted.";	
				array_push($response1["status"],$success);
				$this->response($this->json($response1), 200);
			}
			$this->response('',204);
		}
	}
	###### Update FCM Token to database
	private function UpdateFCMToken() {
		if( $this->get_request_method() != "POST" ) {
			$this->response( '', 406 );
		}
		$cust_id 	   = mysqli_real_escape_string( $this->mysqli, $_REQUEST['customer_id'] );
		$android_token = mysqli_real_escape_string( $this->mysqli, $_REQUEST['android_token'] );
		$ios_token 	   = mysqli_real_escape_string( $this->mysqli, $_REQUEST['ios_token'] );
		if( empty($cust_id) ) {
			$this->response('', 204);
		}
		$response["status"] = array();
		$created_date = date('Y-m-d H:i:s');

		if( !empty( $android_token ) ) {
			$query_fcmToken = "UPDATE regid='$android_token',modified='$created_date' WHERE id='$cust_id'";
		}	
		elseif( !empty( $ios_token ) ) {
			$query_fcmToken = "UPDATE udid='$ios_token',modified='$created_date' WHERE id='$cust_id'";
		}	
		else {
			$this->response( '', 204 );
		}
		### echo $query_fcmToken;
		if( $this->mysqli->query( $query_fcmToken ) ) {
			$arr["status"] = "success";
			$arr['msg']    = "Token saved successfully";
		}
		else {
			$arr["status"] = "failed";
			$arr['msg'] 	= "Token insert failed";
		}
		array_push( $response["status"], $arr );	
		$this->response( $this->json( $response ), 200 );	
	}
	###### End All Action for Customer



















	
	########################################################################################################
	/* —————————————————————————————————————————————————————————————————————————————————————————————————————
	* 
	*
	*
	* ######## Static data Country/State/City/Area/Street/Email&Mobile Check/Mail/SMS/Notification  ########
	*
	*
	* 
	* ——————————————————————————————————————————————————————————————————————————————————————————————————————*/
	###### Country
	private function getCountry() {	
		if( $this->get_request_method() != "POST" ) {
			$this->response( '', 406 );
		}
		$response['Country'] = array();	
		$query = "SELECT * FROM country order by name asc";		
		$r = $this->mysqli->query( $query ) or die( $this->mysqli->error.__LINE__ );
		if( $r->num_rows > 0 ) {
			while( $row = $r->fetch_assoc() ) {
				$arr =  $row; 
				array_push( $response["Country"], $arr );					
			}					
			$this->response( $this->json( $response ), 200 );
		}
		else {
			$this->response($this->json($response), 204);
		}
	}
	###### State
	private function getState() {	
		if( $this->get_request_method() != "POST" ) {
			$this->response( '', 406 );
		}
		$countryid = mysqli_real_escape_string( $this->mysqli, $_REQUEST['countryid'] );
		if( empty( $countryid ) ) {
			$this->response( $this->json( $response ), 204);
		}	
		$response['State'] = array();	
		$query = "SELECT * FROM state where country_id='$countryid' ";		
		$r = $this->mysqli->query( $query ) or die( $this->mysqli->error.__LINE__ );
		if( $r->num_rows > 0 ) {
			while( $row = $r->fetch_assoc() ) {
				$arr =  $row; 				
				array_push( $response["State"], $arr );		
			}							
			$this->response( $this->json( $response ), 200 );
		}
		else {
			$this->response($this->json($response), 204);
		}
	}
	###### City
	private function getCity() {	
		if( $this->get_request_method() != "POST" ) {
			$this->response( '', 406 );
		}
		$stateid = mysqli_real_escape_string( $this->mysqli, $_REQUEST['stateid'] );
		$response['City'] = array();
		if( empty( $stateid ) ) {
			$this->response( $this->json( $response ), 204);
		}	
		$query = "SELECT * FROM city where state_id='$stateid'";		
		$r = $this->mysqli->query( $query ) or die( $this->mysqli->error.__LINE__ );
		if( $r->num_rows > 0 ) {
			while($row = $r->fetch_assoc()){
				$arr =  $row;  	
				array_push( $response["City"], $arr );				
			}			
			$this->response($this->json( $response ), 200);
		}
		else {
			$this->response($this->json($response), 204);
		}
	}
	###### Area
	private function getArea() {	
		if( $this->get_request_method() != "POST" ) {
			$this->response( '', 406 );
		}
		$cityid = mysqli_real_escape_string( $this->mysqli, $_REQUEST['cityid'] );
		$response['Area'] = array();
		if( empty( $cityid ) ) {
			$this->response( $this->json( $response ), 204);
		}	
		$query = "SELECT * FROM area where city_id='$cityid'";		
		$r = $this->mysqli->query( $query ) or die( $this->mysqli->error.__LINE__ );
		if( $r->num_rows > 0 ) {
			while($row = $r->fetch_assoc()){
				$arr =  $row;  	
				array_push( $response["Area"], $arr );				
			}			
			$this->response($this->json( $response ), 200);
		}
		else {
			$this->response($this->json($response), 204);
		}
	}
	###### Street
	private function getStreet() {	
		if( $this->get_request_method() != "POST" ) {
			$this->response( '', 406 );
		}
		$areaid = mysqli_real_escape_string( $this->mysqli, $_REQUEST['areaid'] );
		$response['Street'] = array();
		if( empty( $areaid ) ) {
			$this->response( $this->json( $response ), 204);
		}	
		$query = "SELECT * FROM street where area_id='$areaid'";		
		$r = $this->mysqli->query( $query ) or die( $this->mysqli->error.__LINE__ );
		if( $r->num_rows > 0 ) {
			while($row = $r->fetch_assoc()){
				$arr =  $row;  	
				array_push( $response["Street"], $arr );				
			}			
			$this->response($this->json( $response ), 200);
		}
		else {
			$this->response($this->json($response), 204);
		}
	}
	###### Email&Mobile Check
	private function email_mobile_func( $email_mobile, $id, $tblname, $fieldname ) {			
		//$query = "SELECT id FROM customer WHERE email/mobile='".$email_mobile."'";
		$query = "SELECT {$id} FROM {$tblname} WHERE {$fieldname}='".$email_mobile."'";
		$r = $this->mysqli->query( $query ) or die( $this->mysqli->error.__LINE__ );
		if( $r->num_rows > 0 )  {
			return  "failed";				
		}
		else {
			return  "avail";
		}
	}
	###### Notification
	private function FCMpushNotify_func( $token, $message_send, $notifyID ){			
		$message = $message_send;
		if( !empty($token) ) {
			##########################################
			$serverObject = new SendNotification();	
			$jsonString = $serverObject->sendPushNotificationToGCMSever( $token, $message, $notifyID );	
			$jsonObject = json_decode($jsonString);
			//print_r($jsonObject);
			if($jsonObject->failure != 0) {				
				return "fail";				
			}
			else {
				return "success";			
			}
		}
		else {
			return "fail";	
		}	
	}
	###### Test Notification
	private function Test_FCMpushNotify_Testing(){	
		if($this->get_request_method() != "POST"){
			$this->response('',406);
		}
		$response['pushnotify'] = array();	
		##########################################
		$token   = mysqli_real_escape_string($this->mysqli,$_REQUEST['token']);
		$message = mysqli_real_escape_string($this->mysqli,$_REQUEST['message']);
		$notifyID = "1234";
		##########################################
		if( !empty($token) )  {
			$serverObject_fun =  $this->FCMpushNotify_func( $token, $message, $notifyID );
			//print_r($serverObject_fun);
			##########################################
			if($serverObject_fun == "fail") {
				$arr['status'] = "failed";
				$arr['msg'] = "Please try again later.";
				array_push($response["pushnotify"],$arr);				
			}
			else {
				$arr['status'] = "success";
				$arr['msg'] = "Sent";
				array_push($response["pushnotify"],$arr);			
			}
			$this->response($this->json($response), 200);
		}
		else {
			$this->response('',204);
		}
	}	
	###### SMS
	private function SMS_func( $mobile, $message_send ){			
		$message = $message_send;
		$mobile  = $mobile;
		##########################################
		if( empty($mobile) || empty($message) ){
			return "fail";	
			die();
		}
		##########################################
		$query ="SELECT * FROM setting_sms LIMIT 1";		
		$rs = $this->mysqli->query( $query ) or die( $this->mysqli->error.__LINE__ );
		if($rs->num_rows > 0) {
			while($row = $rs->fetch_assoc()) {
				$sms_url     		 = $row['sms_url'];
				$sms_parameter_name  = unserialize($row['sms_parameter_name']);
				$sms_parameter_value = unserialize($row['sms_parameter_value']);

				$extaParam = "";
				foreach ($sms_parameter_name as $index => $value) {
					$extaParam .= "".$value."=".$sms_parameter_value[$index]."&";
				}

				$sms_parameter_name_mobile 	= $row['sms_parameter_name_mobile'];
				$sms_parameter_name_message = $row['sms_parameter_name_message'];	

				$smsurl = "".$sms_url."?".$extaParam."".$sms_parameter_name_mobile."=".$mobile."&".$sms_parameter_name_message."=".urlencode($message);	
				//echo $smsurl;
				##########################################
				$serverObject = new SendingSMS( $smsurl );	
				$jsonString = $serverObject->sendSMS();	
				$jsonObject = json_decode($jsonString);
 				
				return $jsonString;	
			}		
		}
		else {
			return "fail";	
		}
	}
	###### Test SMS
	private function SMS_func_Testing(){	
		if($this->get_request_method() != "POST"){
			$this->response('',406);
		}
		$response['sms'] = array();	
		##########################################
		$mobile   = mysqli_real_escape_string($this->mysqli,$_REQUEST['mobile']);
		$message_send  = mysqli_real_escape_string($this->mysqli,$_REQUEST['message_send']);
		##########################################
		if(!empty($mobile) && !empty($message_send))  {
			$serverObject_fun =  $this->SMS_func($mobile ,$message_send );
			//print_r($serverObject_fun);
			##########################################
			if($serverObject_fun == "fail") {
				$arr['status'] = "failed";
				$arr['msg'] = "Please try again later. " .$serverObject_fun;
				array_push($response["sms"],$arr);				
			}
			else {
				$arr['status'] = "success";
				$arr['msg'] = "Sent ". $serverObject_fun;
				array_push($response["sms"],$arr);			
			}
			$this->response($this->json($response), 200);
		}
		else {
			$this->response('',204);
		}
	}	
	###### Mail
	private function Mail_func( $Subject, $to, $to_name, $html ) {			
		$Subject = $Subject;
		$to 	 = $to;
		$to_name = $to_name;
		$html    = $html;
		##########################################
		if( empty($Subject) || empty($to) || empty($to_name) || empty($html) ) {
			return "failed";	
			die();
		}
		##########################################
		$query ="SELECT * FROM setting_mail LIMIT 1";		
		$rs = $this->mysqli->query( $query ) or die( $this->mysqli->error.__LINE__ );
		if($rs->num_rows > 0) {
			while($row = $rs->fetch_assoc()) {				
				##########################################
				$mail_type       = $row['mail_type'];
				$Mail_Username   = $row['username'];
				$Mail_Email      = $row['emailid'];
				$Mail_Password   = $row['password'];
				$Mail_SMTPSecure = $row['smtpsecure'];
				$Mail_Port 		 = $row['mail_port'];
				$Mail_Host 		 = $row['mail_host'];				
				##########################################
				if( $mail_type == "smtp" ) {
					$serverObject = new SMTPsendMail($Mail_Username, $Mail_Email, $Mail_Password, $Mail_SMTPSecure, $Mail_Port, $Mail_Host, $Subject, $to, $to_name, $html );
					$jsonString = $serverObject->sendSmtpMail();
					$jsonObject = json_decode($jsonString);
	 				
					return $jsonString;	
				}	
				elseif ( $mail_type == "php" ) {
					$serverObject = new PHPsendMail();
					$jsonString = $serverObject->sendPhpMail( $to, '', $subject, $Mail_Email, $html);
					$jsonObject = json_decode($jsonString);
	 				
					return $jsonString;	
				}	
				else {
					return "failed";
				}		
			}		
		}
		else {
			return "failed";	
		}
	}
	###### Test Mail
	private function Mail_func_Testing() {	
		if($this->get_request_method() != "POST") {
			$this->response('',406);
		}
		$response['mail'] = array();	
		##########################################
		$Subject  = mysqli_real_escape_string($this->mysqli,$_REQUEST['Subject']);
		$to  	  = mysqli_real_escape_string($this->mysqli,$_REQUEST['to']);
		$to_name  = mysqli_real_escape_string($this->mysqli,$_REQUEST['to_name']);
		$html  	  = mysqli_real_escape_string($this->mysqli,$_REQUEST['html']);
		##########################################
		if( !empty($Subject) && !empty($to) && !empty($to_name) && !empty($html) ) {
			$serverObject_fun =  $this->Mail_func( $Subject, $to, $to_name, $html );
			##########################################
			if($serverObject_fun == "failed") {
				$arr['status'] = "failed";
				$arr['msg'] = "Please try again later.".$serverObject_fun;
				array_push( $response["mail"], $arr );				
			}
			else {
				$arr['status'] = "success";
				$arr['msg'] = "Sent".$serverObject_fun;
				array_push( $response["mail"], $arr );			
			}
			$this->response( $this->json($response), 200 );
		}
		else {
			$this->response('',204);
		}
	}	
	######  End Static data Country/State/City/Area/Street/Email&Mobile Check/Mail/SMS/Notification
	########################################################################################
	/* —————————————————————————————————————————————————————————————————————————————————————
	* 
	*
	*
	* ######## Encode JSON ########
	*
	*
	* 
	* ————————————————————————————————————————————————————————————————————————————————————— */
	private function json($data){
		if(is_array($data)){
			return json_encode($data);
		}
	}
}
/* —————————————————————————————————————————————————————————————————————————————————————
* Initiiate Library
* ————————————————————————————————————————————————————————————————————————————————————— */
$api = new API;
$api->processApi();	
?>