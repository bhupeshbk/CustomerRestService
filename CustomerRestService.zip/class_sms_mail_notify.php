<?php
/* —————————————————————————————————————————————————————————————————————————————————————
* Send SMS
* ————————————————————————————————————————————————————————————————————————————————————— */
class SendingSMS
{
	private $smsurl;

    public function __construct($smsurl){
        $this->smsurl 	= $smsurl;
    }
	
    public function sendSMS()
    {
		$live_url  = "".$this->smsurl."";
		$live_url  = html_entity_decode($live_url);
		$parse_url = file_get_contents($live_url );		
		return "done ".$parse_url;
	}
}
/* —————————————————————————————————————————————————————————————————————————————————————
* Send PHP Mail
* ————————————————————————————————————————————————————————————————————————————————————— */
class PHPsendMail
{
	private $to;
    private $cc;
    private $subject;
    private $from;    
    private $html;
	var $headers;

    public function __construct($to, $cc, $subject , $from  ,$html){
        $this->to 		= $to;
        $this->cc 		= $cc;
        $this->subject 	= $subject;
		$this->from 	= $from;
		$this->headers  = NULL;  
		$this->html 	= $html;
    }
	
    public function sendPhpMail(){
		//parseBody
		if($this->html) 
		{
			$content = "
			<style>
				BODY {
				  font-family: verdana;
				  font-size: 10;
				}
			</style>
			".$this->html;
		}
		$this->body = $content;
		//setHeaders
		$this->headers = "From: $this->from\r\n";
		$this->headers.= "MIME-Version: 1.0\r\n";
		$this->headers.= "Content-type: text/html; charset=iso-8859-1\r\n";
		if(!empty($this->cc)){
			$this->headers.= "Cc: $this->cc\r\n";
		}
		//send
		if(mail($this->to, $this->subject, $this->body, $this->headers)) 
			return "done";
		else 
			return "failed";
	}

}
/* —————————————————————————————————————————————————————————————————————————————————————
* Send SMTP PHP Mail
* ————————————————————————————————————————————————————————————————————————————————————— */
class SMTPsendMail
{
	private $Username;
	private $Email;
    private $Password;
    private $SMTPSecure;
    private $Port;
    private $Host;
    private $Subject;
    private $to;
	private $to_name;
	private $html;

    public function __construct($Username, $Email, $Password, $SMTPSecure , $Port ,$Host ,$Subject ,$to ,$to_name ,$html){
        $this->Username   = $Username;
        $this->Email   	  = $Email;
        $this->Password   = $Password;
        $this->SMTPSecure = $SMTPSecure;
		$this->Port       = $Port;
		$this->Host       = $Host;
		$this->Subject    = $Subject;
		$this->To         = $to;
		$this->To_name    = $to_name;
		$this->Html       = $html;
    }
	
    public function sendSmtpMail(){
		require 'PHPMailer/PHPMailerAutoload.php';
		require 'PHPMailer/class.phpmailer.php';
		$mail = new PHPMailer;				
		$mail->isSMTP(true);  
		$mail->SMTPOptions = array(
			'ssl' => array(
			'verify_peer' => false,
			'verify_peer_name' => false,
			'allow_self_signed' => true
			)
		);
		$mail->Host = gethostbyname($this->Host);  
		$mail->SMTPAuth = true;  
		
		$content = "";
		if($this->Html) 
		{
			/*$content = '
			<style>
				BODY {
				  font-family: verdana;
				  font-size: 10;
				}
			</style>
			'.$this->html;*/
			$content = $this->Html;
		}
		$this->body = $content;
	
		$mail->Username 	= $this->Username;                 
		$mail->Password 	= $this->Password;                           
		$mail->SMTPSecure 	= $this->SMTPSecure;                            
		$mail->Port 		= $this->Port;                                 
		
		$mail->setFrom($this->Email,'Streat foods');
		$mail->addAddress($this->To, $this->To_name);     
		$mail->isHTML(true);             
		//$mail->SMTPDebug = 2;                     				
		$mail->Subject 		= $this->Subject;
		$mail->Body    		= $this->body;				
		$host 				= $this->Host;
		$port 				= $this->Port;
					
		if(!$mail->send()) 
			return "failed"; //$mail->ErrorInfo; // failed;
		else 
			return "done";
	}
}
/* —————————————————————————————————————————————————————————————————————————————————————
* New Code for Firebase FCM Push Notification Android
* ————————————————————————————————————————————————————————————————————————————————————— */
class SendNotification { 	
 	private static $API_SERVER_KEY = 'AIzaSyClE-ZHYBdtaw_RvOCCtxvo7AmZX27drL0';
 	// in background when push is recevied
    private static $is_background = "TRUE";
	public function __construct() {		
	
	}
	public function sendPushNotificationToGCMSever($token, $message, $notifyID) {
        $path_to_firebase_cm = 'https://fcm.googleapis.com/fcm/send';

		$fields = array(
            'to' => $token,
            'priority' => 10,
            'notification' => array('title' => 'Streat foods', 'body' =>  $message, 'notifyID' => $notifyID ),
            'data' => array('title' => 'Streat foods', 'message' => $message, 'notifyID' => $notifyID )
            //'data' => array( $res )
        );
 
        $headers = array(
            'Authorization:key=' . self::$API_SERVER_KEY,
            'Content-Type:application/json'
        );	

        // Open connection	
		$ch = curl_init(); 

		// Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $path_to_firebase_cm); 
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 );

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        // Execute post   
        $result = curl_exec($ch); 

        // Close connection      
        curl_close($ch);
        return $result;
	}
 }


?>